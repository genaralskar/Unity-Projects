Created by: Collin Anderson
Created for DGM-1600 Final
Number sprites from Mario & Luigi: Superstar Saga


Known Issues:
-Reloading the game scene causes the game to stop working. Loading a second time fixes it for some reason
so when the game scene is loaded, it loads twice so this doesn't happen. This causes a small flash when restarting the secene

-This game was designed using 16:9 display, other aspect rations may lead to some elements being cut off

-No exit game function. Alt+F4 must be used to exit fullscreen game


Possible Issues:
-There may be some cases when the calculator hides a button when it's not supposed to
I didn't run into any issues when testing, but I can't test every combination so you never know